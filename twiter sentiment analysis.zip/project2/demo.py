import string
from collections import Counter
import streamlit as st

import tweepy

# import textblob
import textblob

st.set_page_config(layout="wide", page_title="Timetable Personalizer", page_icon="random")
# import matplotlib.pyplot as plt
import matplotlib.pyplot as plt

consumerKey = 'hvYE9mvlVDBYnfcFqHbIYG9UH'
consumerSecret = '6HCTNYYFSV0uoINHXbeq9FoM1o7od8rbMJ2ZmnRcJjF6RD6rwd'
accessToken = '966799922627514368-2QIoqrlA66fm3lgXKLe9jK0n63sDnrU'
accessSecret = 'YCi6quNNUDknklfzhAo6l2Ysgo7RaTEcMRHOsoN24JjBn'

authentication = tweepy.OAuthHandler(consumer_key=consumerKey, consumer_secret=consumerSecret)
authentication.set_access_token(accessToken, accessSecret)
api = tweepy.API(authentication)
st.title('Twitter Sentiment Analysis')
col1, col2 = st.columns([1, 2])

with col1:
    keyword = st.text_input('Enter what do you wanna search about?', )
    numberOfTweets = st.number_input('Enter the number of tweets', min_value=1, max_value=200, step=1)
    if st.button('Analyze'):
        tweets = tweepy.Cursor(api.search_tweets, q=keyword, lang='en').items(numberOfTweets)

        with col2:
            positive = 0
            negative = 0
            neutral = 0
            polarity = 0


            def calculatePercentage(a, b):
                return 100 * float(a) / float(b)


            st.subheader('Tweets')
            for tweet in tweets:
                st.text(tweet.text)
                myAnalysis = textblob.TextBlob(tweet.text)
                polarity += myAnalysis.sentiment.polarity
                if myAnalysis.sentiment.polarity == 0:
                    neutral += 1
                elif myAnalysis.sentiment.polarity > 0.00:
                    positive += 1
                elif myAnalysis.sentiment.polarity < 0.00:
                    negative += 1

            positive = calculatePercentage(positive, numberOfTweets)
            negative = calculatePercentage(negative, numberOfTweets)
            neutral = calculatePercentage(neutral, numberOfTweets)

            positive = format(positive, '.2f')
            negative = format(negative, '.2f')
            neutral = format(neutral, '.2f')

            st.write('----------------------------------------------------------------------------')
            st.subheader('Overall Opinion')
            if polarity > 0:
                st.success('Positive')
            elif polarity < 0:
                st.error('Negative')
            elif polarity == 0:
                st.warning('Neutral')
            st.write('----------------------------------------------------------------------------')

            labels = ['Positive [' + str(positive) + '%]', 'Neutral [' + str(neutral) + '%]',
                      'Negative [' + str(negative) + '%]']
            sizes = [positive, neutral, negative]
            colors = ['green', 'yellow', 'red']
            patches, texts = plt.pie(sizes, colors=colors, startangle=90)
            plt.legend(patches, labels, loc="best")
            plt.title('How people are reacting on ' + keyword + ' by analyzing ' + str(numberOfTweets) + ' Tweets.')
            plt.axis('equal')
            plt.tight_layout()
            # show the plot in the streamlit app
            st.set_option('deprecation.showPyplotGlobalUse', False)
            st.pyplot()
